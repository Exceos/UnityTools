using UnityEngine;

namespace UnityTools
{
	public static partial class Vector2Extensions
	{
		public static float CrossProduct(Vector2 a, Vector2 b)
		{
			return a.x * b.y - b.x * a.y;
		}

		public static Vector2 QuadraticLerp(Vector2 a, Vector2 b, Vector2 c, float t)
		{
			var ab = Vector2.Lerp(a, b, t);
			var bc = Vector2.Lerp(b, c, t);

			return Vector2.Lerp(ab, bc, t);
		}

		public static Vector2 CubicLerp(Vector2 a, Vector2 b, Vector2 c, Vector2 d, float t)
		{
			var abc = QuadraticLerp(a, b, c, t);
			var bcd = QuadraticLerp(b, c, d, t);

			return Vector2.Lerp(abc, bcd, t);
		}

		public static Vector3 Convert(Vector2 value)
		{
			return new Vector3(value.x, 0.0f, value.y);
		}
	}
}