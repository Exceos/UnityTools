using UnityEngine;

namespace UnityTools
{
	public static partial class Vector3Extensions
	{
		public static Vector3 QuadraticLerp(Vector3 a, Vector3 b, Vector3 c, float t)
		{
			var ab = Vector3.Lerp(a, b, t);
			var bc = Vector3.Lerp(b, c, t);

			return Vector3.Lerp(ab, bc, t);
		}

		public static Vector3 CubicLerp(Vector3 a, Vector3 b, Vector3 c, Vector3 d, float t)
		{
			var abc = QuadraticLerp(a, b, c, t);
			var bcd = QuadraticLerp(b, c, d, t);

			return Vector3.Lerp(abc, bcd, t);
		}

		public static Vector2 Convert(Vector3 value)
		{
			return new Vector2(value.x, value.z);
		}
	}
}