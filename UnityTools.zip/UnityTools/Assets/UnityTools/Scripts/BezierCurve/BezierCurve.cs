using UnityEngine;

namespace UnityTools
{
	public static partial class BezierCurve
	{
		public static Vector3 GetPointAt(BezierPoint pa, BezierPoint pb, float t)
		{
			return Vector3Extensions.CubicLerp(pa.position, pa.tangentA, pb.tangentB, pb.position, t);
		}
	}
}