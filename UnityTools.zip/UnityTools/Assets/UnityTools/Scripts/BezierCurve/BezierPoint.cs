using System;

using UnityEngine;

namespace UnityTools
{
	[Serializable()]
	public partial struct BezierPoint
	{
		[SerializeField()] public Vector3 position;
		[SerializeField()] public Vector3 tangentA;
		[SerializeField()] public Vector3 tangentB;

		public BezierPoint(Vector3 position, Vector3 tangentA, Vector3 tangentB)
		{
			this.position = position;
			this.tangentA = tangentA;
			this.tangentB = tangentB;
		}
	}
}