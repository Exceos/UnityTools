using UnityEngine;

namespace UnityTools
{
    [AddComponentMenu("UnityTools/BezierCurve/Controllers/BezierCurveController")]
	public partial class BezierCurveController : MonoBehaviour
	{
#if UNITY_EDITOR
		[SerializeField()] public BezierCurveObject[] points;
		[SerializeField()] public int resolution;

		protected virtual void OnDrawGizmos()
		{
			if (points.Length != 0)
			{
				for (int i = 0, n = points.Length - 1; i != n; i++)
				{
					var pa = points[i];
					var pb = points[i + 1];

					if (pa.position != null && pa.tangentA != null && pa.tangentB != null && pb.position != null && pb.tangentA != null && pb.tangentB != null)
					{
						var ba = new BezierPoint(pa.position.position, pa.tangentA.position, pa.tangentB.position);
						var bb = new BezierPoint(pb.position.position, pb.tangentA.position, pb.tangentB.position);

						Gizmos.color = Color.white;
						Gizmos.DrawWireSphere(ba.position, 0.125f);
						Gizmos.DrawWireSphere(ba.tangentA, 0.125f);
						Gizmos.DrawWireSphere(ba.tangentB, 0.125f);
						Gizmos.color = Color.gray;
						Gizmos.DrawLine(ba.position, ba.tangentA);
						Gizmos.DrawLine(ba.position, ba.tangentB);

						Gizmos.color = Color.white;
						Gizmos.DrawWireSphere(bb.position, 0.125f);
						Gizmos.DrawWireSphere(bb.tangentA, 0.125f);
						Gizmos.DrawWireSphere(bb.tangentB, 0.125f);
						Gizmos.color = Color.gray;
						Gizmos.DrawLine(bb.position, bb.tangentA);
						Gizmos.DrawLine(bb.position, bb.tangentB);

						Gizmos.color = Color.yellow;

						for (int k = 0, kn = resolution - 1; k != kn; k++)
						{
							var ta = (float) (k + 0) / kn;
							var tb = (float) (k + 1) / kn;

							var ca = BezierCurve.GetPointAt(ba, bb, ta);
							var cb = BezierCurve.GetPointAt(ba, bb, tb);

							Gizmos.DrawLine(ca, cb);
						}

						continue;
					}
					break;
				}
			}
		}
#endif
	}
}