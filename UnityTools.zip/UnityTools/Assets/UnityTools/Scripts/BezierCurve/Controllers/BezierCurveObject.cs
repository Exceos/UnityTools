using System;

using UnityEngine;

namespace UnityTools
{
	[Serializable()]
	public partial struct BezierCurveObject
	{
#if UNITY_EDITOR
		[SerializeField()] public Transform position;
		[SerializeField()] public Transform tangentA;
		[SerializeField()] public Transform tangentB;
#endif
	}
}