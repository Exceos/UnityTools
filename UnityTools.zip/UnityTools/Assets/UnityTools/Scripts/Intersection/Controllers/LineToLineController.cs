using UnityEngine;

namespace UnityTools
{
    [AddComponentMenu("UnityTools/Intersection/Controllers/LineToLineController")]
    public partial class LineToLineController : MonoBehaviour
    {
#if UNITY_EDITOR
        [SerializeField()] public Transform pointA;
        [SerializeField()] public Transform pointB;
        [SerializeField()] public Transform pointC;
        [SerializeField()] public Transform pointD;

        protected virtual void DrawLine(Vector3 pa, Vector3 pb, Color color)
        {
            Gizmos.color = color;
            Gizmos.DrawWireSphere(pa, 0.125f);
            Gizmos.DrawWireSphere(pb, 0.125f);
            Gizmos.DrawLine(pa, pb);
            Gizmos.color = new Color(color.r, color.g, color.b, color.a / 4.0f);
            Gizmos.DrawRay(pa, (pb - pa).normalized * 100.0f);
            Gizmos.DrawRay(pb, (pa - pb).normalized * 100.0f);
        }

        protected virtual void OnDrawGizmos()
        {
            if (pointA != null && pointB != null)
            {
                DrawLine(pointA.position, pointB.position, Color.red);
            }

            if (pointC != null && pointD != null)
            {
                DrawLine(pointC.position, pointD.position, Color.blue);
            }

            if (pointA != null && pointB != null && pointC != null && pointD != null)
            {
                if (Intersection.LineToLine(Vector3Extensions.Convert(pointA.position), Vector3Extensions.Convert(pointB.position), Vector3Extensions.Convert(pointC.position), Vector3Extensions.Convert(pointD.position), out Vector2 intersection))
                {
                    var intersectionPoint = Vector2Extensions.Convert(intersection);

                    Gizmos.color = Color.yellow;
                    Gizmos.DrawWireSphere(intersectionPoint, 0.125f);
                    Gizmos.DrawLine(intersectionPoint - Vector3.up, intersectionPoint + Vector3.up);
                }
            }
        }
#endif
    }
}