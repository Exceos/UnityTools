using UnityEngine;

namespace UnityTools
{
    public static partial class Intersection
    {
        public static bool LineToLine(Vector2 pa, Vector2 pb, Vector2 pc, Vector2 pd, out Vector2 intersection)
        {
            var determinant = (pa.x - pb.x) * (pc.y - pd.y) - (pa.y - pb.y) * (pc.x - pd.x);

            if (Mathf.Approximately(determinant, Mathf.Epsilon))
            {
                intersection = Vector2.zero;
                return false;
            }

            var px = (pa.x * pb.y - pa.y * pb.x) * (pc.x - pd.x) - (pa.x - pb.x) * (pc.x * pd.y - pc.y * pd.x);
            var py = (pa.x * pb.y - pa.y * pb.x) * (pc.y - pd.y) - (pa.y - pb.y) * (pc.x * pd.y - pc.y * pd.x);

            intersection = new Vector2(px, py) / determinant;
            return true;
        }

        public static bool SegmentToSegment(Vector2 pa, Vector2 pb, Vector2 pc, Vector2 pd, out Vector2 intersection)
        {
            var a = pa;
            var b = pb - pa;
            var c = pc;
            var d = pd - pc;

            var direction = c - a;
            var crossProduct = Vector2Extensions.CrossProduct(b, d);

            if (Mathf.Abs(crossProduct) <= Mathf.Epsilon)
            {
                if (Mathf.Abs(Vector2Extensions.CrossProduct(direction, b)) <= Mathf.Epsilon)
                {
                    var bb = Vector2.Dot(b, b);
                    var db = Vector2.Dot(d, b);

                    var ta = Vector2.Dot(direction, b / bb);
                    var tb = ta + db / bb;

                    if (db < 0.0f)
                    {
                        var t = ta;
                        ta = tb;
                        tb = t;
                    }

                    if (ta <= 1.0f && tb >= 0.0f)
                    {
                        var t = Mathf.Lerp(Mathf.Max(0.0f, ta), Mathf.Min(1.0f, tb), 0.5f);
                        intersection = a + t * b;
                        return true;
                    }
                }

                intersection = Vector2.zero;
                return false;
            }

            var e = Vector2Extensions.CrossProduct(direction, d) / crossProduct;
            var f = Vector2Extensions.CrossProduct(direction, b) / crossProduct;

            if (e >= 0.0f && e <= 1.0f && f >= 0.0f && f <= 1.0f)
            {
                intersection = a + e * b;
                return true;
            }

            intersection = Vector2.zero;
            return false;
        }
    }
}