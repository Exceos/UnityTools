using UnityEngine;

namespace UnityTools
{
    [AddComponentMenu("UnityTools/Trajectory/Controllers/TrajectoryController")]
    public partial class TrajectoryController : MonoBehaviour
    {
#if UNITY_EDITOR
        [SerializeField()] public Transform pointA;
        [SerializeField()] public Transform pointB;
        [SerializeField()] public AnimationCurve curve;
        [SerializeField()] public float length;
        [SerializeField()] public int resolution;

        protected virtual void DrawPoint(Vector3 point, Color color)
        {
            Gizmos.color = color;
            Gizmos.DrawWireSphere(point, 0.125f);
        }

        protected virtual void OnDrawGizmos()
        {
            if (pointA != null)
            {
                DrawPoint(pointA.position, Color.red);
            }

            if (pointB != null)
            {
                DrawPoint(pointB.position, Color.blue);
            }

            if (pointA != null && pointB != null)
            {
                Gizmos.color = Color.yellow;

                for (int i = 0, n = resolution - 1; i != n; i++)
                {
                    var ta = (float) (i + 0) / n;
                    var pa = Trajectory.GetPointAt(pointA.position, pointB.position, curve, length, ta);

                    var tb = (float) (i + 1) / n;
                    var pb = Trajectory.GetPointAt(pointA.position, pointB.position, curve, length, tb);

                    Gizmos.DrawLine(pa, pb);
                }
            }
        }
#endif
    }
}