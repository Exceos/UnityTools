using UnityEngine;

namespace UnityTools
{
    public static partial class Trajectory
    {
        public static Vector3 GetPointAt(Vector3 pa, Vector3 pb, AnimationCurve curve, float length, float t)
        {
            var ab = Vector3.Lerp(pa, pb, t);
            return new Vector3(ab.x, ab.y + length * curve.Evaluate(t), ab.z);
        }
    }
}